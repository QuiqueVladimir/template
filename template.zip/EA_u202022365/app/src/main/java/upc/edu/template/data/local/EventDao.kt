package upc.edu.template.data.local

object EventDao{

}
