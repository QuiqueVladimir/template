package upc.edu.template.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import upc.edu.template.data.model.EventoEntity

