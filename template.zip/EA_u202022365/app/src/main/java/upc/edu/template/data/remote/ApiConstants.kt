package upc.edu.template.data.remote

object ApiConstants {
    const val BASE_URL = "https://sugary-wool-penguin.glitch.me/"
}